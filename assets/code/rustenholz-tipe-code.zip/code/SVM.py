import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

class SVM:
    def __init__(self,echantillon,labels,kernel=lambda x,y:(x.T).dot(y)):
        self.X=echantillon
        self.labels=labels
        self.Dy=np.diag(labels)
        self.y=np.array([labels]).T
        self.solution=np.zeros((len(labels),1))
        self.active=[]
        self.b=0
        self.kernel=kernel
        
    def fdual(self,alpha):
        n=len(self.labels)
        K=np.zeros((n,n))
        for i in range(n):
            for j in range(n):
                K[i][j]=self.kernel(self.X[i],self.X[j])
        G=self.Dy.dot(K.dot(self.Dy))
        e=np.ones((len(self.labels),1))
        return 0.5*(alpha.T).dot(G.dot(alpha))-(e.T).dot(alpha)         ###A accélérer?
    
    def yalpha(self,alpha):
        return (self.y.T).dot(alpha)
        
    def solve(self):
        self.solve1()
        self.reglerbiais()
        
    def solve1(self):
        cons=[{'type' : 'ineq', 'fun' : lambda x:x},{'type' : 'eq', 'fun' : self.yalpha}]
        
        self.solution = opt.minimize(self.fdual,self.solution,constraints=cons).x
        for i in range(len(self.labels)):
            if self.solution[i]>0: #voire eps
                self.active.append(i)
    
    def reglerbiais(self):
        self.b=opt.minimize_scalar(lambda x:-1*self.marge(x)).x

    def marge(self,b):
        x=self.X[0]
        m=b
        for i in self.active:
            m+=self.solution[i]*self.y[i]*self.kernel(x,self.X[i])#(x.T).dot(self.X[i])
        m*=self.y[0]
            
        for n in range(1,len(self.labels)):
            x=self.X[n]
            S=b
            for i in self.active:
                S+=self.solution[i]*self.y[i]*self.kernel(x,self.X[i])#(x.T).dot(self.X[i])
            if self.y[n]*S<m:
                m=self.y[n]*S
        return float(m)
        
    def predict(self,x):
        S=self.b
        for i in self.active:
            S+=self.solution[i]*self.y[i]*self.kernel(x,self.X[i])#(x.T).dot(self.X[i])
        if S>0:
            return 1
        elif S==0:
            return 0
        else :
            return -1
            
    def predictFlou(self,x):
        S=self.b
        for i in self.active:
            S+=self.solution[i]*self.y[i]*self.kernel(x,self.X[i])#(x.T).dot(self.X[i])
        return S

def RBF(x,y):
    sigma=0.1
    return np.exp(-np.linalg.norm(y-x)**2/(2*sigma**2))
    
M=np.zeros((200,200))
N=np.zeros((200,200))
X=[]
Y=[]

D=-0.4
R1=0.1
R2=0.2
for _ in range(20):
    X.append([[D-R1+2*R1*np.random.random()],[D-R1+2*R1*np.random.random()]])
    Y.append(1)
for _ in range(20):
    r=0.5*R2*np.random.random()+R2
    theta=np.random.random()*2*np.pi
    X.append([[D+r*np.cos(theta)],[D+r*np.sin(theta)]])
    Y.append(-1)
D=0.4
R1=0.1
R2=0.2
for _ in range(20):
    X.append([[D-R1+2*R1*np.random.random()],[D-R1+2*R1*np.random.random()]])
    Y.append(1)
for _ in range(20):
    r=0.5*R2*np.random.random()+R2
    theta=np.random.random()*2*np.pi
    X.append([[D+r*np.cos(theta)],[D+r*np.sin(theta)]])
    Y.append(-1)
    
X=np.array(X)
Y=np.array(Y)

u=SVM(X,Y,RBF)
u.solve()
for y,i in zip(np.linspace(-1,1,200),range(200)):
    if i%10==0:
        print(i)
    for x,j in zip(np.linspace(-1,1,200),range(200)):
        M[i][j] = u.predict(np.array([x,y]))
        for n in range(len(u.labels)):
            if n in u.active and abs(y-u.X[n][1])<=0.02 and abs(x-u.X[n][0])<=0.02 :
                M[i][j]=2*u.labels[n]
            elif abs(y-u.X[n][1])<=0.01 and abs(x-u.X[n][0])<=0.01 :
                M[i][j]=2*u.labels[n]
plt.matshow(M,origin='lower',cmap='gray')
plt.show()
        

        

        
    
        