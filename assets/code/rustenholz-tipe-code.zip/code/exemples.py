import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as img
import math

###Exemples

#Ex 1 : Deux classes
def ex1():
    exemples=[]
    Dx=-1.2
    Dy=0.7
    R1=0.4
    R2=0.2
    for _ in range(20):
        E=np.array([[Dx-R1+2*R1*np.random.random()],[Dy-R1+2*R1*np.random.random()]])
        S=np.array([[1]])
        exemples.append([E,S])
    Dx=1.4
    Dy=0.7
    R1=0.1
    R2=0.2
    for _ in range(20):
        E=np.array([[Dx-R1+2*R1*np.random.random()],[Dy-R1+2*R1*np.random.random()]])
        S=np.array([[-1]])
        exemples.append([E,S])
    return(exemples)
    
#TerreMer : "TerreMer/ex1.png"
def imgToEx(lien,N):
    image = img.imread(lien)
    exemples=[]
    Cim=image.shape[0]
    C=3.
    for _ in range(N):
        x=np.random.randint(image.shape[0])
        y=np.random.randint(image.shape[1])
        E=np.array([[(x/Cim-.5)*C,(y/Cim-.5)*C]])
        S=np.array([[image[x][y][0]]])
        exemples.append([E,S])
    return(exemples)
