import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

def err(x,x0):
    return (x-x0)**2
    
def errp(x,x0) :
    return 2*(x-x0)
    
def s0(e):
    return e[0]+e[1]
    
def s(e,wlist):
    res = np.dot(wlist[0],e)
    for w in wlist[1:] :
        res=np.dot(w,res)
    return res
    
def main():
    fig=plt.figure()
    ax=fig.add_subplot(1,1,1,projection='3d')
    
    A=2
    R=100
    
    N=50
    E=[np.array([[np.random.random()*200-100,np.random.random()*200-100]]).T for _ in range(N)]
    

    W1=np.linspace(-A,A,R)
    W2=np.linspace(-A,A,R)

    Z=np.zeros((len(W1),len(W2)))
    
    for i in range(len(W1)):
        for j in range(len(W2)):
            w=np.array([[W1[i],W2[j]]])
            Z[i,j]=1/N * sum(err(s(e,[w]),s0(e)) for e in E)

    W1,W2=np.meshgrid(W1,W2)
    surf=ax.plot_surface(W1,W2,Z,cmap=cm.coolwarm)
    
    fig2=plt.figure()
    W1=np.linspace(-A,A,R)
    W2=np.linspace(-A,A,R)

    U=np.zeros((len(W1),len(W2)))
    V=np.zeros((len(W1),len(W2)))
    
    
    for i in range(len(W1)):
        for j in range(len(W2)):
            w=np.array([[W1[i],W2[j]]])
            V[i,j]=1/N * sum(errp(s(e,[w]),s0(e))*e[0] for e in E) #Spécifique à Js en schéma 21
            U[i,j]=1/N * sum(errp(s(e,[w]),s0(e))*e[1] for e in E)
            
        #Sens inversé ici : voir conventions d'orientation    
        
    W1,W2=np.meshgrid(W1,W2)
    #Q=plt.quiver(W1[::3][::3],W2[::3][::3],U[::3][::3],V[::3][::3],pivot='tail',units='xy')
    Q=plt.streamplot(W1,W2,U,V,color=(U**2+V**2)**0.5,cmap=cm.coolwarm,density=3,linewidth=2)
    
    plt.show()
    
    
main()