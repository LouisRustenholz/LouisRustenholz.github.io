import numpy as np
import matplotlib.pyplot as plt
import math

def save():
    labels=open("train-labels.idx1-ubyte",'rb')
    images=open("train-images.idx3-ubyte",'rb')

    labels.read(8)
    images.read(16)
    
    N=np.random.randint(60000)
    labels.read(N)
    images.read(28*28*N)
    number=int(labels.read(1)[0])
    i1=images.read(28*28)
    M=np.zeros((28,28))
    for n in range(28*28):
        M[n//28][n%28]=int(i1[n])
    plt.matshow(M,cmap="gray")
    plt.savefig("Chiffres/"+str(number)+"_"+str(N)+".png",bbox_inches='tight')
    plt.close()
    
    labels.close()
    images.close()
    
for _ in range(100):
    save()