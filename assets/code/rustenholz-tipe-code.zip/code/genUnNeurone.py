import numpy as np
import matplotlib.pyplot as plt

class NeuralNet :
    def __init__(self,profondeur,largeurs,biais=False):
        self.profondeur=profondeur
        self.largeurs=largeurs      #Liste de taille profondeur+1
        self.poids=[np.zeros((largeurs[n+1],largeurs[n])) for n in range(profondeur)]
        self.activation=[lambda x:x for n in range(profondeur)]
        self.activationPrime=[lambda x:1 for n in range(profondeur)]
        self.agregation=[[lambda w,x:w.dot(x) for j in range(largeurs[n+1])] for n in range(profondeur)]
        self.agregationPrime=[[[0 for k in range(2*largeurs[n])] for j in range(largeurs[n+1])] for n in range(profondeur)]
        for n in range(profondeur):
            for j in range(largeurs[n+1]):
                for k in range(2*largeurs[n]):
                    if k<largeurs[n] : # d(h_j)/d(w_jk)
                        self.agregationPrime[n][j][k]=lambda w,x,k=k:x[k]
                    else :  #d(h_j)/d(x_k) avec changement k->k-Ln
                        self.agregationPrime[n][j][k]=lambda w,x,k=k:w[k-largeurs[n]]
        self.biais=biais
        if biais:
            self.setBiais()
    
    def propagation(self,entree):
        x=entree
        if self.biais:
            x=np.append(x,0)#Choix sans impact
        for n in range(self.profondeur):
            y=np.zeros((self.largeurs[n+1]))
            for j in range(self.largeurs[n+1]):
                y[j]=self.activation[n](self.agregation[n][j](self.poids[n][j],x))
            x=y
        return x
    
    def retropropagation(self,entree,sortieAttendue,pas,dw0=0,alpha=0): #dw0*alpha -> terme d'inertie
        X=[np.zeros((L)) for L in self.largeurs]      #Propagation initiale
        X[0]=entree
        if self.biais :
            X[0]=np.append(X[0],0) #Choix sans impact
        for n in range(self.profondeur):
            for j in range(self.largeurs[n+1]):
                X[n+1][j]=self.activation[n](self.agregation[n][j](self.poids[n][j],X[n]))
        
        e=np.zeros((self.largeurs[-1],1))               #Initialisation
        for j in range(self.largeurs[-1]):
            e[j]=(X[-1][j]-sortieAttendue[j])*self.activationPrime[-1](self.agregation[-1][j](self.poids[-1][j],X[-2]))
        
        dw=0
        if alpha!=0:
            dw=dw0.copy()
            
        for n in range(self.profondeur,0,-1):
            Werr=np.zeros(self.poids[n-1].shape)        #Calcul de Werr
            for j in range(self.largeurs[n]):
                for k in range(self.largeurs[n-1]):
                    Werr[j][k]=e[j]*self.agregationPrime[n-1][j][k](self.poids[n-1][j],X[n-1])
            
            ebis=np.zeros((self.largeurs[n-1],1))       #Calcul de e_(n-1)
            for k in range(self.largeurs[n-1]):
                if n>1:
                    ebis[k][0]=self.activationPrime[n-2](self.agregation[n-2][k](self.poids[n-2][k],X[n-2]))*sum(e[j][0]*self.agregationPrime[n-1][j][k+self.largeurs[n-1]](self.poids[n-1][j],X[n-1]) for j in range(self.largeurs[n]))
            e=ebis

            if alpha!=0:                        #Mise à jour des poids
                dw[n-1]=-Werr*pas+dw0[n-1]*alpha
                self.poids[n-1]=self.poids[n-1]+dw[n-1]
            else :
                self.poids[n-1]=self.poids[n-1]-Werr*pas    
                
        return dw
            
    
    def poidsRandom(self,a=1.,ab=1.):
        for n in range(self.profondeur):
            for j in range(self.largeurs[n+1]):
                for k in range(self.largeurs[n]-1):
                    self.poids[n][j][k]=a*(2*np.random.random()-1)
                self.poids[n][j][self.largeurs[n]-1]=ab*(2*np.random.random()-1)
                    
    def erreur(self,entree,sortieAttendue):
        y=self.propagation(entree)
        return float(1/2*((y-sortieAttendue).T).dot(y-sortieAttendue))
        
    def setBiais(self):
        for n in range(self.profondeur):
            self.largeurs[n]+=1
        self.poids=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(self.profondeur)]

        for n in range(self.profondeur-1):
            for j in range(self.largeurs[n+1]-1):
                self.agregation[n][j]=lambda w,x,f=self.agregation[n][j]:f(w[:-1],x[:-1])+w[-1]
                self.agregationPrime[n][j].insert(self.largeurs[n]-1,lambda w,x:1.)
                self.agregationPrime[n][j].append(lambda w,x:0.)
            self.agregation[n].append(lambda w,x:0.)#Choix sans impact
            self.agregationPrime[n].append([lambda w,x:0. for k in range(2*self.largeurs[n])])#De même
        
        n=self.profondeur-1
        for j in range(self.largeurs[n+1]):   #Au bout, on n'a pas ajouté de nodes
            self.agregation[n][j]=lambda w,x,f=self.agregation[n][j]:f(w[:-1],x[:-1])+w[-1]
            self.agregationPrime[n][j].insert(self.largeurs[n]-1,lambda w,x:1.)
            self.agregationPrime[n][j].append(lambda w,x:0.)
        self.biais=True
        
def teach(NN,exemples,N,pas,alpha=0):
    dw=0.
    if alpha!=0:
        dw=[np.zeros(NN.poids[n].shape) for n in range(NN.profondeur)]       
    for _ in range(N):
        k=np.random.randint(len(exemples))
        if alpha!=0:
            dw=NN.retropropagation(exemples[k][0],exemples[k][1],pas,dw,alpha)
        else:
            NN.retropropagation(exemples[k][0],exemples[k][1],pas)

def tanh(x):
    return np.tanh(x)

def tanhp(x):
    return 1.-tanh(x)**2

def sig(x):
    return 1./(1.+np.exp(-x))
    
def sigp(x):
    return np.exp(-x)/np.exp(2*np.log(1.+np.exp(-x)))
        
def testError(NN,exemples):
    S=0
    for ex in exemples:
        S+=NN.erreur(ex[0],ex[1])
    return S/len(exemples)
        
NN1=NeuralNet(1,[2,1])
p=1
NN1.agregation=[[lambda w,x:np.exp(-.5*(w-x).dot(w-x)) for j in range(NN1.largeurs[n+1])] for n in range(p)]+[[lambda w,x:w.dot(x) for j in range(NN1.largeurs[n+1])] for n in range(p,NN1.profondeur)]
for n in range(p):
    for j in range(NN1.largeurs[n+1]):
        for k in range(2*NN1.largeurs[n]):
            if k<NN1.largeurs[n] : # d(h_j)/d(w_jk)
                NN1.agregationPrime[n][j][k]=lambda w,x,k=k:(x[k]-w[k])*np.exp(-.5*(w-x).dot(w-x))
            else :  #d(h_j)/d(x_k) avec changement k->k-Ln
                NN1.agregationPrime[n][j][k]=lambda w,x,k=k:(w[k-NN1.largeurs[n]]-x[k-NN1.largeurs[n]])*np.exp(-.5*(w-x).dot(w-x))

NN1.setBiais()
NN1.poidsRandom(2,2)

NN1.activation=[lambda x:x,tanh]
NN1.activationPrime=[lambda x:0.*x+1.,tanhp]

def imgToEx(lien,N,C=1.5):
    image = img.imread(lien)
    exemples=[]
    Cim=image.shape[0]
    for _ in range(N):
        x=np.random.randint(image.shape[0])
        y=np.random.randint(image.shape[1])
        E=np.array([-(x/Cim-.5)*C,-(y/Cim-.5)*C])
        S=np.array([2*image[x][y][0]-1])
        exemples.append([E,S])
    return(exemples)
    
def totImgToEx(lien,C=1.5):
    image = img.imread(lien)
    exemples=[]
    Cim=image.shape[0]
    for x in range(image.shape[0]):
        for y in range(image.shape[1]):
            E=np.array([-(x/Cim-.5)*C,-(y/Cim-.5)*C])
            S=np.array([2*image[x][y][0]-1])
            exemples.append([E,S])
    return(exemples)

lien="TerreMer/ex2.png"
exemples=totImgToEx(lien,2)
image = img.imread(lien)
plt.imshow(image)
plt.savefig("TerreMer/source.png",bbox_inches='tight')
plt.close()

print(NN1.poids)
print(testError(NN1,exemples))
for _ in range(100):
    teach(NN1,exemples,10000,1,0.01)
    print(_)
    print(NN1.poids)
    print(testError(NN1,exemples))

    M=np.zeros((200,200))
    for y,i in zip(np.linspace(-1,1,200),range(200)):
        for x,j in zip(np.linspace(-1,1,200),range(200)):
            M[i][j] = NN1.propagation(np.array([x,y]))
            # for ex in exemples:
            #     if abs(y-ex[0][1][0])<=0.01 and abs(x-ex[0][0][0])<=0.01 :
            #         M[i][j]=2*ex[1][0][0]
    plt.matshow(M,cmap='gray')
    plt.savefig("TerreMer/training"+str(_)+".png",bbox_inches='tight')
    plt.close()
