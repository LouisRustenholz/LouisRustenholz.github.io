import numpy as np
import matplotlib.pyplot as plt

class NeuralNet :
    def __init__(self,profondeur,largeurs):
        self.profondeur=profondeur
        self.largeurs=largeurs      #Liste de taille profondeur+1
        self.poids=[np.zeros((largeurs[n+1],largeurs[n])) for n in range(profondeur)]
        self.activations=[lambda x:x for n in range(profondeur)]
        self.activationsPrime=[lambda x:1 for n in range(profondeur)]
        
    def propagation(self,entree):
        x=entree
        for n in range(self.profondeur):
            x=self.poids[n].dot(x)
            x=self.activations[n](x)
        return x
        
    def setAllActivation(self,f,fPrime):
        self.activations=[f]*self.profondeur
        self.activationsPrime=[fPrime]*self.profondeur
        
    def erreursPartielles(self,entree,sortieAttendue):  #On prend erreur quadratique
        X=[entree]
        H=[entree]
        for n in range(self.profondeur):                #On propage en retenant les valeurs
            H.append(self.poids[n].dot(X[-1]))
            X.append(self.activations[n](H[-1]))
            
        errW=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(self.profondeur)]  #On initialise
        e=[np.zeros((self.largeurs[n],1)) for n in range(self.profondeur+1)]
        e[self.profondeur]=(X[self.profondeur]-sortieAttendue)*self.activationsPrime[self.profondeur-1](H[self.profondeur])
        
        for n in range(self.profondeur,0,-1):       #Retropropagation
            errW[n-1]=e[n].dot(X[n-1].T)
            e[n-1]=self.activationsPrime[n-1](H[n-1])*(self.poids[n-1].T).dot(e[n])
        return errW
    
    def correction(self,entree,sortieAttendue,pas):
        errW=self.erreursPartielles(entree,sortieAttendue)
        
        for n in range(self.profondeur):
            self.poids[n]=self.poids[n] - pas*errW[n]
            
    def erreur(self,entree,sortieAttendue):
        y=self.propagation(entree)
        return float(1/2*((y-sortieAttendue).T).dot(y-sortieAttendue))
        
    def poidsRandom(self):
        for n in range(self.profondeur):
            for j in range(self.largeurs[n+1]):
                for k in range(self.largeurs[n]):
                    self.poids[n][j][k]=np.random.random()
            
def teach(NN,exemples,N,pas):
    for _ in range(N):
        k=np.random.randint(len(exemples))
        NN.correction(exemples[k][0],exemples[k][1],pas)
        
        
NN1=NeuralNet(1,[2,3])
NN1.poidsRandom()

M=np.array([[1.0,0.0],[1.0,1.0],[0.0,1.0]])

ex=[]
for _ in range(10000):
    E=np.random.rand(2,1)
    S=M.dot(E)
    ex.append([E,S])
    
teach(NN1,ex,1000,0.1)
err=sum(NN1.erreur(ex[k][0],ex[k][1]) for k in range(len(ex)))/len(ex)
print(err)
for W in NN1.poids :
    print(W)
