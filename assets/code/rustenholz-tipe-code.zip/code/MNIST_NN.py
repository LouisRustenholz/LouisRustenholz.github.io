import numpy as np
import matplotlib.pyplot as plt
import math

class NeuralNet :
    def __init__(self,profondeur,largeurs):
        self.profondeur=profondeur
        self.largeurs=largeurs      #Liste de taille profondeur+1
        self.poids=[np.zeros((largeurs[n+1],largeurs[n])) for n in range(profondeur)]
        self.activations=[lambda x:x for n in range(profondeur)]
        self.activationsPrime=[lambda x:1 for n in range(profondeur)]
        
    def propagation(self,entree):
        x=entree
        for n in range(self.profondeur):
            x=self.poids[n].dot(x)
            x=self.activations[n](x)
        return x
        
    def setAllActivation(self,f,fPrime):
        self.activations=[f]*self.profondeur
        self.activationsPrime=[fPrime]*self.profondeur
        
    def erreursPartielles(self,entree,sortieAttendue):  #On prend erreur quadratique
        X=[entree]
        H=[entree]
        for n in range(self.profondeur):                #On propage en retenant les valeurs
            H.append(self.poids[n].dot(X[-1]))
            X.append(self.activations[n](H[-1]))
            
        errW=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(self.profondeur)]  #On initialise
        e=[np.zeros((self.largeurs[n],1)) for n in range(self.profondeur+1)]
        e[self.profondeur]=(X[self.profondeur]-sortieAttendue)*self.activationsPrime[self.profondeur-1](H[self.profondeur])
        
        for n in range(self.profondeur,0,-1):       #Retropropagation
            errW[n-1]=e[n].dot(X[n-1].T)
            e[n-1]=self.activationsPrime[n-1](H[n-1])*(self.poids[n-1].T).dot(e[n])
        return errW
    
    def correction(self,entree,sortieAttendue,pas):
        errW=self.erreursPartielles(entree,sortieAttendue)
        
        for n in range(self.profondeur):
            self.poids[n]=self.poids[n] - pas*errW[n]
            
    def erreur(self,entree,sortieAttendue):
        y=self.propagation(entree)
        return float(1/2*((y-sortieAttendue).T).dot(y-sortieAttendue))
        
    def poidsRandom(self):
        for n in range(self.profondeur):
            for j in range(self.largeurs[n+1]):
                for k in range(self.largeurs[n]):
                    self.poids[n][j][k]=np.random.random()/1000
            
def teach(NN,exemples,N,pas):
    for _ in range(N):
        k=np.random.randint(len(exemples))
        NN.correction(exemples[k][0],exemples[k][1],pas)
        
def affiche():
    labels=open("train-labels.idx1-ubyte",'rb')
    images=open("train-images.idx3-ubyte",'rb')

    labels.read(8)
    images.read(16)
    
    N=np.random.randint(60000)
    labels.read(N)
    images.read(28*28*N)
    print(int(labels.read(1)[0]))
    i1=images.read(28*28)
    M=np.zeros((28,28))
    for n in range(28*28):
        M[n//28][n%28]=int(i1[n])
    plt.matshow(M,cmap="gray")
    plt.show()
    
    labels.close()
    images.close()
    
def tanh(x):
    return np.tanh(x)

def tanhp(x):
    return 1.-tanh(x)**2

def sig(x):
    return 1./(1.+np.exp(-x))
    
def sigp(x):
    return np.exp(-x)/np.exp(2*np.log(1.+np.exp(-x)))
    
def testUnique(NN):
    labels=open("t10k-labels.idx1-ubyte",'rb')
    images=open("t10k-images.idx3-ubyte",'rb')
    labels.read(8)
    images.read(16)
    N=np.random.randint(10000)
    labels.read(N)
    images.read(28*28*N)
    
    l=labels.read(1)
    im=images.read(28*28)
    E=np.array([[int(im[k]) for k in range(28*28)]]).T
    print(int(l[0]))
    print(np.array([[0,1,2,3,4,5,6,7,8,9]]))
    S = NN.propagation(E)
    print(S.T)
    Ep=np.zeros((28,28))
    for n in range(28*28):
        Ep[n//28][n%28]=E[n]
    plt.matshow(Ep,cmap="gray")
    
    
    labels.close()
    images.close()

def creerExemples(N):
    labels=open("train-labels.idx1-ubyte",'rb')
    images=open("train-images.idx3-ubyte",'rb')
    labels.read(8)
    images.read(16)
    exemples=[]
    for _ in range(N):
        l=labels.read(1)
        im=images.read(28*28)
        E=np.array([[int(im[k])/255 for k in range(28*28)]]).T
        S=np.zeros((10,1))
        S[int(l[0])][0]=1.
        exemples.append([E,S])
    return exemples
    
def creerExemplesVerif(N):
    labels=open("t10k-labels.idx1-ubyte",'rb')
    images=open("t10k-images.idx3-ubyte",'rb')
    labels.read(8)
    images.read(16)
    exemples=[]
    for _ in range(N):
        l=labels.read(1)
        im=images.read(28*28)
        E=np.array([[int(im[k])/255 for k in range(28*28)]]).T
        S=np.zeros((10,1))
        S[int(l[0])][0]=1.
        exemples.append([E,S])
    return exemples
    
def testError(NN,exemples):
    S=0
    for ex in exemples:
        S+=NN.erreur(ex[0],ex[1])
    return S/len(exemples)
    
def propError(NN,exemples):
    S=0
    for ex in exemples:
        sol=0
        rep=0
        repmax=0.
        y=NN.propagation(ex[0])
        for k in range(10):
            if ex[1][k][0]==1. :
                sol=k
            if y[k][0]>=repmax :
                repmax=y[k][0]
                rep=k
        if rep!=sol:
            S+=1
    return S/len(exemples)
        

def ouvrirPoids(NN):
    for _ in range(200):
        M=np.zeros((28,28))
        for n in range(28*28):
            M[n//28][n%28]=NN.poids[0][_][n]
        plt.matshow(M,cmap="gray")
        plt.savefig(str(_)+".png",bbox_inches='tight')
        plt.close()
    


# NN=NeuralNet(2,[28*28,200,10])
# NN.poidsRandom()
# NN.activations=[tanh,sig]
# NN.activationsPrime=[tanhp,sigp]
    
exemples = creerExemples(60000)

# teach(NN,exemples,1000000,0.1)
#
# k=np.random.randint(len(exemples))
# print(exemples[k][1].T)
# print(NN.propagation(exemples[k][0]).T)
# 
print("Erreur sur base d'apprentissage:",testError(NN,exemples))
 
exemplesVerif=creerExemplesVerif(10000)
 
print("Erreur sur base de test",testError(NN,exemplesVerif))
# 
# testUnique(NN)
# plt.show()