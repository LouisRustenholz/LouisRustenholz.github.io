import numpy as np
import matplotlib.pyplot as plt
import math

class NeuralNet :
    def __init__(self,profondeur,largeurs,biais=False):
        self.profondeur=profondeur
        self.largeurs=largeurs      #Liste de taille profondeur+1
        self.biais=biais
        if biais :
            for _ in range(profondeur):
                self.largeurs[_]+=1
        self.poids=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(profondeur)]
        self.activations=[lambda x:x for n in range(profondeur)]
        self.activationsPrime=[lambda x:1 for n in range(profondeur)]
        
    def propagation(self,entree):
        x=entree
        if self.biais:
            x=np.append(x,[[1.]],axis=0)
            for n in range(self.profondeur):
                x[self.largeurs[n]-1]=1.
                x=self.poids[n].dot(x)
                x=self.activations[n](x)
        else:
            for n in range(self.profondeur):
                x=self.poids[n].dot(x)
                x=self.activations[n](x)
        return x
        
    def setAllActivation(self,f,fPrime):
        self.activations=[f]*self.profondeur
        self.activationsPrime=[fPrime]*self.profondeur
        
    def erreursPartielles(self,entree,sortieAttendue):  #On prend erreur quadratique
        X=[entree]
        H=[entree]
        if self.biais:
            X=[np.append(entree,[[1.]],axis=0)]
            H=[np.append(entree,[[1.]],axis=0)]
            for n in range(self.profondeur):                #On propage en retenant les valeurs
                H[-1][self.largeurs[n]-1]=1.
                X[-1][self.largeurs[n]-1]=1.
                H.append(self.poids[n].dot(X[-1]))
                X.append(self.activations[n](H[-1]))
        else :
            for n in range(self.profondeur):                #On propage en retenant les valeurs
                H.append(self.poids[n].dot(X[-1]))
                X.append(self.activations[n](H[-1]))
            
        errW=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(self.profondeur)]  #On initialise
        e=[np.zeros((self.largeurs[n],1)) for n in range(self.profondeur+1)]
        e[self.profondeur]=(X[self.profondeur]-sortieAttendue)*self.activationsPrime[self.profondeur-1](H[self.profondeur])
        for n in range(self.profondeur,0,-1):       #Retropropagation
            errW[n-1]=e[n].dot(X[n-1].T)
            e[n-1]=self.activationsPrime[n-1](H[n-1])*(self.poids[n-1].T).dot(e[n])
        return errW
    
    def correction(self,entree,sortieAttendue,pas):
        errW=self.erreursPartielles(entree,sortieAttendue)
        for n in range(self.profondeur):
            self.poids[n]=self.poids[n] - pas*errW[n]
            if self.biais and n<self.profondeur-1:
                self.poids[n][self.largeurs[n+1]-1]=np.zeros((self.largeurs[n]))
            
    def erreur(self,entree,sortieAttendue):
        y=self.propagation(entree)
        return float(1/2*((y-sortieAttendue).T).dot(y-sortieAttendue))
        
    def poidsRandom(self,amp=1.,ampbiais=10.):
        for n in range(self.profondeur):
            for j in range(self.largeurs[n+1]):
                for k in range(self.largeurs[n]):
                    self.poids[n][j][k]=2*amp*np.random.random()-amp
                if self.biais :
                    self.poids[n][j][self.largeurs[n]-1]=2*ampbiais*np.random.random()-ampbiais
            
def teach(NN,exemples,N,pas):
    for _ in range(N):
        k=np.random.randint(len(exemples))
        NN.correction(exemples[k][0],exemples[k][1],pas)
    
def tanh(x):
    return np.tanh(x)

def tanhp(x):
    return 1.-tanh(x)**2

def sig(x):
    return 1./(1.+np.exp(-x))
    
def sigp(x):
    return np.exp(-x)/np.exp(2*np.log(1.+np.exp(-x)))
    
def testError(NN,exemples):
    S=0
    for ex in exemples:
        S+=NN.erreur(ex[0],ex[1])
    return S/len(exemples)
    
def propError(NN,exemples):
    S=0
    for ex in exemples:
        sol=0
        rep=0
        repmax=0.
        y=NN.propagation(ex[0])
        for k in range(10):
            if ex[1][k][0]==1. :
                sol=k
            if y[k][0]>=repmax :
                repmax=y[k][0]
                rep=k
        if rep!=sol:
            S+=1
    return S/len(exemples)
    


# NN=NeuralNet(2,[2,20,1],biais=True)
# NN.poidsRandom(2,2)
# NN.activations=[tanh,tanh]
# NN.activationsPrime=[tanhp,tanhp]

# exemples =[]
# D=-0.4
# R1=0.1
# R2=0.2
# for _ in range(20):
#     E=np.array([[D-R1+2*R1*np.random.random()],[D-R1+2*R1*np.random.random()]])
#     S=np.array([[1]])
#     exemples.append([E,S])
# for _ in range(20):
#     r=0.5*R2*np.random.random()+R2
#     theta=np.random.random()*2*np.pi
#     E=np.array([[D+r*np.cos(theta)],[D+r*np.sin(theta)]])
#     S=np.array([[-1]])
#     exemples.append([E,S])
# D=0.4
# R1=0.1
# R2=0.2
# for _ in range(20):
#     E=np.array([[D-R1+2*R1*np.random.random()],[D-R1+2*R1*np.random.random()]])
#     S=np.array([[1]])
#     exemples.append([E,S])
# for _ in range(20):
#     r=0.5*R2*np.random.random()+R2
#     theta=np.random.random()*2*np.pi
#     E=np.array([[D+r*np.cos(theta)],[D+r*np.sin(theta)]])
#     S=np.array([[-1]])
#     exemples.append([E,S])

# for _ in range(1000000):
#     teach(NN,exemples,50000,0.1)
#     print(NN.poids)
#     print(_)
# 
#     M=np.zeros((200,200))
#     for y,i in zip(np.linspace(-1,1,200),range(200)):
#         for x,j in zip(np.linspace(-1,1,200),range(200)):
#             M[i][j] = NN.propagation(np.array([[x],[y]]))[0][0]
#             for ex in exemples:
#                 if abs(y-ex[0][1][0])<=0.01 and abs(x-ex[0][0][0])<=0.01 :
#                     M[i][j]=2*ex[1][0][0]
#     plt.matshow(M,origin='lower',cmap='gray')
#     plt.savefig("training"+str(_)+".png",bbox_inches='tight')
#     plt.close()
#     #plt.show()

M=np.zeros((200,200))
#N=[np.zeros((200,200)) for _ in range(20)]
for y,i in zip(np.linspace(-2,2,200),range(200)):
    for x,j in zip(np.linspace(-2,2,200),range(200)):
        M[i][j] = NN.propagation(np.array([[x],[y]]))[0][0]
        for ex in exemples:
            if abs(y-ex[0][1][0])<=0.01 and abs(x-ex[0][0][0])<=0.01 :
                M[i][j]=2*ex[1][0][0]
        #for n in range(20):
        #    N[n][i][j] = tanh(x*NN.poids[0][n][0]+y*NN.poids[0][n][1]+NN.poids[0][n][2])*NN.poids[1][0][n]/abs(NN.poids[1][0][n])
plt.matshow(M,origin='lower',cmap='gray')
plt.contour(M,np.linspace(-1,1,100))
# for n in range(20):
#     plt.contour(N[n],levels=[-.1,0,.1],alpha=abs(NN.poids[1][0][n])/6)
plt.show()

# NN=NeuralNet(2,[1,5,1],biais=True)
# X=np.linspace(-20,20,500)
# NN.poidsRandom(1,10)
# NN.activations=[tanh,tanh,tanh]
# NN.activationsPrime=[tanhp,tanhp,tanhp]
# Y=[]
# for x in X :
#     Y.append(NN.propagation(np.array([[x]]))[0][0])
# plt.plot(X,Y)
# plt.show()
# print(NN.poids)