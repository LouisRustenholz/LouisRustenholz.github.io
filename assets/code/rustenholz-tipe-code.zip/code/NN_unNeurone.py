import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as img
import math

class NeuralNet :
    def __init__(self,profondeur,largeurs,biais=False):
        self.profondeur=profondeur
        self.largeurs=largeurs      #Liste de taille profondeur+1
        self.biais=biais
        if biais :
            for _ in range(profondeur):
                self.largeurs[_]+=1
        self.poids=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(profondeur)]
        self.activations=[lambda x:x for n in range(profondeur)]
        self.activationsPrime=[lambda x:1 for n in range(profondeur)]
        
    def propagation(self,entree):
        x=entree
        if self.biais:
            x=np.append(x,[[1.]],axis=0)
            for n in range(self.profondeur):
                x[self.largeurs[n]-1]=1.
                x=self.poids[n].dot(x)
                x=self.activations[n](x)
        else:
            for n in range(self.profondeur):
                x=self.poids[n].dot(x)
                x=self.activations[n](x)
        return x
        
    def setAllActivation(self,f,fPrime):
        self.activations=[f]*self.profondeur
        self.activationsPrime=[fPrime]*self.profondeur
        
    def erreursPartielles(self,entree,sortieAttendue):  #On prend erreur quadratique
        X=[entree]
        H=[entree]
        if self.biais:
            X=[np.append(entree,[[1.]],axis=0)]
            H=[np.append(entree,[[1.]],axis=0)]
            for n in range(self.profondeur):                #On propage en retenant les valeurs
                H[-1][self.largeurs[n]-1]=1.
                X[-1][self.largeurs[n]-1]=1.
                H.append(self.poids[n].dot(X[-1]))
                X.append(self.activations[n](H[-1]))
        else :
            for n in range(self.profondeur):                #On propage en retenant les valeurs
                H.append(self.poids[n].dot(X[-1]))
                X.append(self.activations[n](H[-1]))
            
        errW=[np.zeros((self.largeurs[n+1],self.largeurs[n])) for n in range(self.profondeur)]  #On initialise
        e=[np.zeros((self.largeurs[n],1)) for n in range(self.profondeur+1)]
        e[self.profondeur]=(X[self.profondeur]-sortieAttendue)*self.activationsPrime[self.profondeur-1](H[self.profondeur])
        for n in range(self.profondeur,0,-1):       #Retropropagation
            errW[n-1]=e[n].dot(X[n-1].T)
            e[n-1]=self.activationsPrime[n-1](H[n-1])*(self.poids[n-1].T).dot(e[n])
        return errW
    
    def correction(self,entree,sortieAttendue,pas):
        errW=self.erreursPartielles(entree,sortieAttendue)
        for n in range(self.profondeur):
            self.poids[n]=self.poids[n] - pas*errW[n]
            if self.biais and n<self.profondeur-1:
                self.poids[n][self.largeurs[n+1]-1]=np.zeros((self.largeurs[n]))
            
    def erreur(self,entree,sortieAttendue):
        y=self.propagation(entree)
        return float(1/2*((y-sortieAttendue).T).dot(y-sortieAttendue))
        
    def poidsRandom(self,amp=1.,ampbiais=10.):
        for n in range(self.profondeur):
            for j in range(self.largeurs[n+1]):
                for k in range(self.largeurs[n]):
                    self.poids[n][j][k]=2*amp*np.random.random()-amp
                if self.biais :
                    self.poids[n][j][self.largeurs[n]-1]=2*ampbiais*np.random.random()-ampbiais
            
def teach(NN,exemples,N,pas):
    for _ in range(N):
        k=np.random.randint(len(exemples))
        NN.correction(exemples[k][0],exemples[k][1],pas)
    
def tanh(x):
    return np.tanh(x)

def tanhp(x):
    return 1.-tanh(x)**2

def sig(x):
    return 1./(1.+np.exp(-x))
    
def sigp(x):
    return np.exp(-x)/np.exp(2*np.log(1.+np.exp(-x)))
    
def testError(NN,exemples):
    S=0
    for ex in exemples:
        S+=NN.erreur(ex[0],ex[1])
    return S/len(exemples)
    
def propError(NN,exemples):
    S=0
    for ex in exemples:
        sol=0
        rep=0
        repmax=0.
        y=NN.propagation(ex[0])
        for k in range(10):
            if ex[1][k][0]==1. :
                sol=k
            if y[k][0]>=repmax :
                repmax=y[k][0]
                rep=k
        if rep!=sol:
            S+=1
    return S/len(exemples)
    
def imgToEx(lien,N,C=1.5):
    image = img.imread(lien)
    exemples=[]
    Cim=image.shape[0]
    for _ in range(N):
        x=np.random.randint(image.shape[0])
        y=np.random.randint(image.shape[1])
        E=np.array([[-(x/Cim-.5)*C],[-(y/Cim-.5)*C]])
        S=np.array([[2*image[x][y][0]-1]])
        exemples.append([E,S])
    return(exemples)
    
def totImgToEx(lien,C=1.5):
    image = img.imread(lien)
    exemples=[]
    Cim=image.shape[0]
    for x in range(image.shape[0]):
        for y in range(image.shape[1]):
            E=np.array([[-(x/Cim-.5)*C],[-(y/Cim-.5)*C]])
            S=np.array([[2*image[x][y][0]-1]])
            exemples.append([E,S])
    return(exemples)

lien="TerreMer/ex2.png"
exemples=imgToEx(lien,100,2)
image = img.imread(lien)
plt.imshow(image)
plt.savefig("TerreMer/source.png",bbox_inches='tight')
plt.close()

NN=NeuralNet(1,[2,1],biais=False)
NN.poidsRandom(2,2)
NN.activations=[tanh,tanh]
NN.activationsPrime=[tanhp,tanhp]

print(NN.poids)
for _ in range(100):
    teach(NN,exemples,50000,0.1)
    print(_)
    print(NN.poids)

    M=np.zeros((200,200))
    for y,i in zip(np.linspace(-1,1,200),range(200)):
        for x,j in zip(np.linspace(-1,1,200),range(200)):
            M[i][j] = NN.propagation(np.array([[x],[y]]))[0][0]
            # for ex in exemples:
            #     if abs(y-ex[0][1][0])<=0.01 and abs(x-ex[0][0][0])<=0.01 :
            #         M[i][j]=2*ex[1][0][0]
    plt.matshow(M,cmap='gray')
    plt.savefig("TerreMer/training"+str(_)+".png",bbox_inches='tight')
    plt.close()
    #plt.show()
